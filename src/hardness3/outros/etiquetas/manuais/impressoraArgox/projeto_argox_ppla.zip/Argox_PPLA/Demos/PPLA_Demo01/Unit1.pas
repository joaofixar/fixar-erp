unit Unit1;

{-------------------------------------------------------------------------------
 >> Demo 01 de uso da PPLA_Unit <<

        Este demo demonstra como utilizar a unit para gerar script PPLA de
        impress�o de etiquetas, com informa��es contidas em um listview.
 
        S�o impressos 1 c�digo de barras do tipo 128 ABC e 1 texto descritivo
        em cada uma das etiquetas.

        Caso deseje recompilar o programa demo antes de adquirir o fonte da unit,
        � necess�rio copiar o arquivo PPLA_Unit.dcu para o diret�rio Lib de
        instala��o do Delphi, no caso do Delphi 6 pro exemplo
        C:\Arquivos de programas\Borland\Delphi6\Lib

        Caso j� tenha adquirido a PPLA_Unit registrada, voc� pode adiciona-la ao
        seu projeto, clicando em Menu> Project> Add to Project.

 Para remover a mensagem de "N�o Registrado" � necess�rio adquirir a PPLA_Unit
 com fontes. Para informa��es sobre como adquirir o produto visite nosso site.

 Atenciosamente,
  Victory Fernandes
   TKS Software
   www.igara.com.br
-------------------------------------------------------------------------------}

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, ComCtrls, Printers, RxGIF, ExtCtrls, jpeg, ShellApi, PPLA_Unit;

type
  TForm1 = class(TForm)
    GroupBox2: TGroupBox;
    Memo1: TMemo;
    Button4: TButton;
    Button2: TButton;
    SaveDialog1: TSaveDialog;
    Panel1: TPanel;
    Button5: TButton;
    PageControl1: TPageControl;
    TabSheet1: TTabSheet;
    GroupBox1: TGroupBox;
    Label2: TLabel;
    Label3: TLabel;
    Label1: TLabel;
    Edit2: TEdit;
    Edit3: TEdit;
    Button3: TButton;
    ListView1: TListView;
    Edit1: TEdit;
    Button1: TButton;
    TabSheet2: TTabSheet;
    GroupBox3: TGroupBox;
    Label7: TLabel;
    Label8: TLabel;
    Edit4: TEdit;
    Edit5: TEdit;
    GroupBox4: TGroupBox;
    Label14: TLabel;
    Label15: TLabel;
    Edit18: TEdit;
    Edit19: TEdit;
    OpenDialog1: TOpenDialog;
    Label4: TLabel;
    Label5: TLabel;
    Label6: TLabel;
    Image3: TImage;
    Image2: TImage;
    TabSheet3: TTabSheet;
    Image4: TImage;
    GroupBox6: TGroupBox;
    Label25: TLabel;
    Label26: TLabel;
    Label27: TLabel;
    Label28: TLabel;
    Label29: TLabel;
    Label30: TLabel;
    Label31: TLabel;
    Label32: TLabel;
    Label33: TLabel;
    Label34: TLabel;
    Label35: TLabel;
    Label36: TLabel;
    Image1: TImage;
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Edit2Enter(Sender: TObject);
    procedure Edit2Exit(Sender: TObject);
    procedure Edit1KeyPress(Sender: TObject; var Key: Char);
    procedure Button3Click(Sender: TObject);
    procedure Button4Click(Sender: TObject);
    procedure ListView1DblClick(Sender: TObject);
    procedure Button5Click(Sender: TObject);
    procedure Label29Click(Sender: TObject);

  private
    { Private declarations }
  public
    { Public declarations }

  end;

var
  Form1: TForm1;
  Impressora : Integer;

type
  TPassThroughData = Record                                                     //Declara��o utilizada em Impressao_Paralela
   nLen: Integer;
   Data: Array [0..2000] of byte;
  end;

implementation

{$R *.dfm}

//Envio de Comandos pela Porta Paralela
Procedure Impressao_Paralela(Texto: String);
var
 PTBlock : TPassThroughData;
Begin
 PTBlock.nLen := Length(Texto);
 StrPCopy(@PTBlock.Data, Texto);
 Escape(printer.handle, PASSTHROUGH, 0, @PTBlock, nil);
end;
procedure TForm1.Button1Click(Sender: TObject);
var
 x: integer;
begin

//--- Impress�o de C�digo de Barras ---
{Impressora de Codigo de Barras Argox usando linguagem PPLA em ASCII}
memo1.Lines.Clear;
if strtoint(edit1.text) > 0 then
 begin
  for x:=1 to listview1.Items.Count do
  begin
  Abrir_Etiqueta_PPLA;
   Comando_STX_m;
   Comando_STX_c(480);
   Comando_STX_L;
   Comando_H(12);
   Comando_D(2,2);
  Texto_PPLA(1,                                                         //Orientacao
             '3',                                                       //Fonte
             '1',                                                       //Multiplicador_Horizontal
             '1',                                                       //Multiplicador_Vertical
             0,                                                         //Subtipo_Fonte
             strtoint(edit5.text),                                      //Eixo_Y
             strtoint(edit4.text),                                      //Eixo_X
             copy(listview1.Items.Item[x-1].SubItems.Strings[0],0,25)); //Texto                                    //Texto

  Incrementa_Numerico(+10);
  Codigo_Barras_PPLA(1,                                                 //Orientacao
                     'a',                                               //Tipo_Codigo_Barra
                     '5',                                               //Largura_Barra_Larga
                     '3',                                               //Largura_Barra_Fina
                     50,                                                //Altura_Barra
                     strtoint(edit5.text),                              //Eixo_Y
                     strtoint(edit4.text),                              //Eixo_X
                     listview1.Items.Item[x-1].Caption);                //Codigo                                        //Codigo

  memo1.Lines.AddStrings(Fechar_Etiqueta_PPLA(StrToInt(edit1.Text)));
 end;
 end;
end;

procedure TForm1.Button2Click(Sender: TObject);
begin
 //impressao do codigo de barras
 if memo1.Lines.Count > 0 then
  begin
   Printer.BeginDoc;
   Impressao_paralela(memo1.Lines.Text);
   Printer.EndDoc;
  end;
end;

procedure TForm1.Edit2Enter(Sender: TObject);
begin
//Altera cor de edit
TEdit(sender).color := claqua;
end;

procedure TForm1.Edit2Exit(Sender: TObject);
begin
//Altera cor de edit
TEdit(sender).color := clwindow;
end;

procedure TForm1.Edit1KeyPress(Sender: TObject; var Key: Char);
begin
//Aceita apenas caracteres numericos
if not (key in ['0','1','2','3','4','5','6','7','8','9',#32,#08]) then
 key := #0;
end;

procedure TForm1.Button3Click(Sender: TObject);
var
 i: integer;
begin
//adiciona item a lista
if (trim(edit2.text) <> '') and
   (trim(edit3.text) <> '') then
 begin
  with ListView1.Items do
   begin
    i := Count;
    Insert(i);
    Item[i].Caption := edit2.text;
    Item[i].SubItems.Insert( 0, edit3.text);
   end;
 end;
end;

procedure TForm1.Button4Click(Sender: TObject);
begin
 //Salva arquivo de Script de Impressao
 if memo1.Lines.Count > 0 then
  begin
   savedialog1.InitialDir := extractfiledir(Application.ExeName);
   if savedialog1.Execute then
    memo1.Lines.SaveToFile(savedialog1.FileName);
  end;
end;

procedure TForm1.ListView1DblClick(Sender: TObject);
begin
 //exclui item da lista
 if listview1.ItemIndex <> -1 then
  listview1.Items.Delete(listview1.ItemIndex);
end;

procedure TForm1.Button5Click(Sender: TObject);
begin
 //Abre arquivo de Script de Impressao
 opendialog1.InitialDir := extractfiledir(Application.ExeName);
 if opendialog1.Execute then
  memo1.Lines.loadfromFile(opendialog1.FileName);
end;

procedure TForm1.Label29Click(Sender: TObject);
begin
 ShellExecute(Self.Handle, nil, PChar(TLabel(sender).caption), nil, nil, SW_NORMAL);
end;




end.
